/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gameapplication;

/**
 *
 * @author Click IT
 */
public class GameApplication {

    public static void main(String[] args) {
        
    }
}
