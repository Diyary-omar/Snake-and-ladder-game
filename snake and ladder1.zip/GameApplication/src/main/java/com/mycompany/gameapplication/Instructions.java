package com.mycompany.gameapplication;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;


public class Instructions extends JFrame {

	private JPanel contentPane;
	
	/**
	 * Create the frame.
	 */
	public Instructions() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize( 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblJustRollThe = new JLabel("تەنها زارەکە هەلبدە " ,JLabel.CENTER);
		lblJustRollThe.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblJustRollThe.setBounds(10, 38, 414, 29);
		contentPane.add(lblJustRollThe);
		
		JLabel lblTryToClimb = new JLabel("هەوڵ بدە بەسەر قادرمەکان سەربکەویت بۆئەوەی سەلامەت بیت!!" ,JLabel.CENTER);
		lblTryToClimb.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblTryToClimb.setBounds(0, 75, 434, 29);
		contentPane.add(lblTryToClimb);
		
		JLabel lblFromTheSnakesfirst = new JLabel("کاتێ مارەکە پێتەوە ئەدات دەگەرێیتەوە سەر ئەو شووێنەی کەکلکی مارەی لییە" ,JLabel.CENTER);
		lblFromTheSnakesfirst.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblFromTheSnakesfirst.setBounds(0, 115, 434, 35);
		contentPane.add(lblFromTheSnakesfirst);
		
		JLabel lblFinalPositionWins = new JLabel("بۆ ئەوە ببی بەبراوە پێویستەبگەیت بەخانەی 100!!!!" ,JLabel.CENTER);
		lblFinalPositionWins.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblFinalPositionWins.setBounds(0, 161, 434, 29);
		contentPane.add(lblFinalPositionWins);
		
		setLocationRelativeTo(null);
	}
}
