package com.mycompany.gameapplication;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

public class AboutMe extends JDialog {

    private final JPanel contentPanel = new JPanel();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        try {
            AboutMe dialog = new AboutMe();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Create the dialog.
     */
    public AboutMe() {
        setTitle("About us");
        setModal(true);
        setModalityType(ModalityType.APPLICATION_MODAL);
        setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setResizable(false);
        setBounds(50, 50, 350, 175);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);

        JLabel lblNewLabel1 = new JLabel("Diyary Omar");
        JLabel lblNewLabel2 = new JLabel("Danial Dara");
        JLabel lblNewLabel3 = new JLabel("Frishta jala");
        JLabel lblNewLabel4 = new JLabel("Rayan Faraidwn");
        JLabel lblNewLabel5 = new JLabel("Zakaria Ahmad");
        lblNewLabel1.setBounds(10, 11, 147, 24);
        lblNewLabel2.setBounds(11, 20, 150, 30);
        lblNewLabel3.setBounds(12, 30, 155, 36);
        lblNewLabel4.setBounds(13, 40, 160, 42);
        lblNewLabel5.setBounds(14, 50, 165, 48);
        contentPanel.add(lblNewLabel1);
        contentPanel.add(lblNewLabel2);
        contentPanel.add(lblNewLabel3);
        contentPanel.add(lblNewLabel4);
        contentPanel.add(lblNewLabel5);

        JLabel lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBounds(167, 14, 176, 19);
        contentPanel.add(lblNewLabel_1);
        {
            JPanel buttonPane = new JPanel();
            buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
            getContentPane().add(buttonPane, BorderLayout.SOUTH);
            {
                JButton okButton = new JButton("OK");
                okButton.setFont(new Font("Tahoma", Font.BOLD, 14));
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dispose();
                    }
                });
                okButton.setActionCommand("OK");
                buttonPane.add(okButton);
                getRootPane().setDefaultButton(okButton);
            }
        }
        setLocationRelativeTo(null);
    }
}
